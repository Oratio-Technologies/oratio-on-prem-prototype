import { createClient } from '@supabase/supabase-js';

// const supabaseUrl = import.meta.env.VITE_SUPABASE_URL
// const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY

const supabaseUrl = 'https://cmqmloclnvesqovcdhvy.supabase.co';
const supabaseAnonKey =
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNtcW1sb2NsbnZlc3FvdmNkaHZ5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3Mzc2NDYxODcsImV4cCI6MjA1MzIyMjE4N30.Q_mlFr5eMy4Dtp2oRPuCFIrlRb4jiPVep4e0-HkzMF0';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
